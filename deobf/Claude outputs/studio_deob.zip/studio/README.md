# Roblox Studio runner + deobfuscator

This runs a Luraph v15 script inside **Roblox Studio** (a real Roblox environment,
so the anti-tamper checks pass and the key is correct), captures the decrypted
protos, and sends them back to your PC to be lifted into source.

Why Studio and not the sandbox: the script's real code is encrypted with a key
the anti-tamper checks build from the live Roblox environment. The offline
sandbox can't reproduce that key, so the payload stays encrypted. Studio *is*
that environment, so the key comes out right.

## What you need
- Python 3 and Node.js on your PC
- Your `deobf` folder (this uses its `src/vmmap.js` and the lifter)
- Roblox Studio

## Steps

1. Put the obfuscated script here as `script.lua` (the 598 KB one is already here;
   replace it to do a different script).

2. Point the server at your deobf folder and start it. On Windows:
   ```
   set DEOB_ROOT=C:\Users\temuun\OneDrive\Desktop\tools\luraph-deobfuscator better\deobf
   python deob_server.py
   ```
   It prints `listening on http://127.0.0.1:8000`. Leave it running.

3. In Studio: **Game Settings -> Security -> Allow HTTP Requests = ON**.

4. Open the Studio **command bar** (View -> Command Bar) and paste the entire
   contents of `studio_runner.luau`. Press Enter.

5. Watch the Output window. It fetches the instrumented script, runs it, prints
   how many proto sets it captured, and posts them back. The server saves
   `capture.json` and tries to lift it.

## What comes back
- `capture.json` — the captured decrypted protos (this is the important one)
- `deobfuscated.luau` — the lifted source, **if** the capture already matches the
  lifter's format

## Important (please read)
This is **v1 and I can't test Studio from here**, so expect one round of fixing:

- If Studio errors when running the script (it pokes a few executor-only
  functions, which I've stubbed), copy the exact Output error and send it — I'll
  adjust the stubs.
- `capture.json` is the real prize. The first run tells me the exact shape of
  what Studio captures; I turn that into the lifter's input format and give you
  the final converter. **So after the first run, send me `capture.json`** (or tell
  me what the Output said) and I finish the lift.

The pipeline is: `script.lua` -> (server instruments) -> Studio runs + captures
-> posts back -> lifter -> `deobfuscated.luau`.
